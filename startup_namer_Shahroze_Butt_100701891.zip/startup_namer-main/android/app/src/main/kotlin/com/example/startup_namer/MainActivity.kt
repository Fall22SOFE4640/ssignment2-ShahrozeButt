package com.example.startup_namer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
